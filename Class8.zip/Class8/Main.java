public class Main {

	public static void main(String[] args) {
		
		Object a[] = new Object[6];
		
		Clothing x = new Clothing();
		Jersey y = new Jersey(30, "Curry", "Cotton", "L", "Blue and Gold");
		SwimSuit z = new SwimSuit("Plastic", "XS", "hot pink", 'M', "Speedo", "Louis Vutton");
		
		a[0] = x;
		a[1] = y;
		a[2] = z;
		a[3] = new String("cat");
		a[4] = new Integer(67);

		System.out.println(x);
		
		for(int i = 0;i<3;++i){
			if(a[i].getClass().getName().equals("SwimSuit")){
				System.out.println(((SwimSuit)a[i]).getBrand());
			}else if(a[i].getClass().getName().equals("Jersey")){
				System.out.println(((Jersey)a[i]).getPlayerNumber());
			}
		}
	}


	
	
	
	
	
}
