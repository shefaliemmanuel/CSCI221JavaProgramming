
public class Clothing {

	private String Material;
	private String size;
	private String color;
	
	Clothing(){
		this.Material = "undefined";
		this.size = "undefined";
		this.color = "undefined";	
	}
	
	Clothing(String material, String size, String color) {
		Material = material;
		this.size = size;
		this.color = color;
	}
	
	public String getMaterial() {
		return Material;
	}
	public void setMaterial(String material) {
		Material = material;
	}
	public String getSize() {
		return size;
	}
	public void setSize(String size) {
		this.size = size;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
}
