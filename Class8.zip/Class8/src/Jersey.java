public class Jersey extends Clothing{

	private int PlayerNumber;
	private String Name;
	
	public Jersey(int playerNumber, String name) {
		super();
		PlayerNumber = playerNumber;
		Name = name;
	}
	public Jersey(int playerNumber, String name, String Material, String Size, String Color) {
		super(Material, Size, Color);
		PlayerNumber = playerNumber;
		Name = name;
	}
	public int getPlayerNumber() {
		return PlayerNumber;
	}
	public void setPlayerNumber(int playerNumber) {
		PlayerNumber = playerNumber;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
}
