public class SwimSuit extends Clothing{

		private char gender;
		private String type;		
		private String brand;
		
		public SwimSuit(String material, String size, String color, char gender, String type, String brand) {
			super(material, size, color);
			this.gender = gender;
			this.type = type;
			this.brand = brand;
		}
		
		public SwimSuit(char gender, String type, String brand) {
			super();
			this.gender = gender;
			this.type = type;
			this.brand = brand;
		}
		
		public char getGender() {
			return gender;
		}
		public void setGender(char gender) {
			this.gender = gender;
		}
		public String getType() {
			return type;
		}
		public void setType(String type) {
			this.type = type;
		}
		public String getBrand() {
			return brand;
		}
		public void setBrand(String brand) {
			this.brand = brand;
		}		
}
