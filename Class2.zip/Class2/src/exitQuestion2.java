import java.util.*;

public class exitQuestion2 {

	public static void main(String[] args) {
	Scanner shefScanner= new Scanner(System.in);
	System.out.print("Please enter a list of letters and numbers seperated by a space");
	
	while(true){
	String side1= shefScanner.next();
	if(side1.equals("-1")){
		break;
	}
	int length1= shefScanner.nextInt();
	String side2= shefScanner.next();
	if(side2.equals("-1")){
		break;
	}
	int length2= shefScanner.nextInt();

	if(side1.equals("AB") && side2.equals("BC")){
		System.out.print("AC:");
		int length3= (length1*length1) + (length2*length2);
		double sqrtLen3= Math.sqrt(length3);
		System.out.printf("%.0f",sqrtLen3);
		System.out.print("	Area:");
		int area= (length1 * length2)/2;
		System.out.println(area);
	}
	if(side1.equals("BC") && side2.equals("AC")){
		System.out.print("AB:");
		int length3= (length1*length1) + (length2*length2);
		double sqrtLen3= Math.sqrt(length3);
		System.out.printf("%.0f",sqrtLen3);
		System.out.print("	Area:");
		int area= (length1 * length2)/2;
		System.out.println(area);
	}
	if(side1.equals("AC") && side2.equals("AB")){
		System.out.print("BC:");
		int length3= (length1*length1) + (length2*length2);
		double sqrtLen3= Math.sqrt(length3);
		System.out.printf("%.0f",sqrtLen3);
		System.out.print("	Area:");
		int area= (length1 * length2)/2;
		System.out.println(area);
	}
	if(side1. equals("BC") && side2.equals("AC")){
		System.out.print("AB:");
		int length3= (length1*length1) + (length2*length2);
		double sqrtLen3= Math.sqrt(length3);
		System.out.printf("%.0f",sqrtLen3);
		System.out.print("	Area:");
		int area= (length1 * length2)/2;
		System.out.println(area);
	}
	else{
		break;
	}
}}}
