import java.util.Scanner;

public class class2 {

	public static void main(String[] args) {

		System.out.printf("%20.2f", 123456.789);
		System.out.printf("%20.2f", 123456.789);
		System.out.println();
		System.out.printf("%20.2f", 1256.789);
		System.out.printf("%20.2f", 1456.789);
		System.out.println();
		System.out.printf("%20.2f", 56.789);
		System.out.printf("%20.2f", 56.789);
		System.out.println();

		int x = 5 + (2 / 5);
		System.out.println(x);
		System.out.println();

		System.out.println();
		for (int i = 0; i < 5; i++) {
			System.out.println(i);
		}

		System.out.println();
		for (int i = 0; i < 1000; i += 10) {
			System.out.println(i);
		}

		System.out.println();
		for (int i = 1; i < 1000; i *= 2) {
			System.out.println(i);
		}

		System.out.println();
		int n = 1000;
		for (int i = 1; i < n; i *= 10) {
			System.out.println(i);
		}

/*		// while loop
		Scanner shefScanner = new Scanner(System.in);
		System.out.print("Please enter a positive interger:");
		while (shefScanner.hasNext()) {
			if (shefScanner.hasNextInt()){
				int r = shefScanner.nextInt();
				if (r == 0) {
					break; //breaks you out regardless
				} else if (r < 0) {
					System.out.println("Enter a positive number, please.");
				} else {
					System.out.println(2 * r);
				}
			}else{
				System.out.println("Please enter positive interger");
				shefScanner.next();
			     }
			}
			System.out.println("Thanks for playing!");

	}*/
	Scanner shefsScanner= new Scanner(System.in);	
	while(true){
		//String w= shefsScanner.next();
		//System.out.println(w.charAt(w.length()-1));
		
		String u= shefsScanner.next(); //USER TYPES INTO COMP
		String y = shefsScanner.next(); //USER TYPES INTO COMP
		if (u.equals(y)){ //EQUALS OBJ
			System.out.println("They are equal!");
		}else{
			System.out.println("They are not equal!");
		}
		
		
		
	}
	
	}
	
}

