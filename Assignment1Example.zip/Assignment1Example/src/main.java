
public class main {

	public static void main(String[] args) {
		getPGM pic= new getPGM("football.pgm"); //open up file
		new showGrayImage(ImageProcessing.negative(pic.getImage()), "Gray Image");
		new showGrayImage(ImageProcessing.addImages(pic2.getImage(),pic1.getImage()), "Gray Image");

	}

}
