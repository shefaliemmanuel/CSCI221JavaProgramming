import java.util.Scanner;

public class ABProblem {

	public static void main(String[] args) {

		Scanner myScan = new Scanner(System.in);		
		int bill = myScan.nextInt();
		int paid = myScan.nextInt();
		
		//////////////////////////////////////////////////////////////////
		// Algorithm: 
		// 				- Walk through each digit in the input
		//              - When you find the first non-9, print
		//                the difference with 9 and add 0s traversed
		//              - Handle edges cases (input size is 1 or all 9s)
		
		while(!(bill == 0 && paid == 0)){			
			String changeDue = ""+(paid-bill);

			if(changeDue.length() == 1){
				System.out.println('9'-changeDue.charAt(0));
			}else{
				boolean PrintedNumber = false;
				for(int i = 0;i < changeDue.length();++i){
					if(changeDue.charAt(i) != '9'){
						System.out.print('9'-changeDue.charAt(i));
						for(int j = 0;j < changeDue.length()-i-1;++j){
							System.out.print('0');
						}
						System.out.println();
						PrintedNumber = true;
						break;
					}
				}
				if(!PrintedNumber){
					System.out.println('0');
				}
			}
			// Get next input pair
			bill = myScan.nextInt();
			paid = myScan.nextInt();
		}
		
		
	}

}
