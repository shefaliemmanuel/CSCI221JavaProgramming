
public class CupOfCoffee {

	//Attributes:
	private String material;
	public int size;
	private boolean empty;
	
	//Constructor method:
	// - no return type stated
	// - the name must be the same as the class
	// - purpose: Initialize the objects attributes
	// INITIALIZE
	CupOfCoffee(){
		material = "Plastic";
		size = 5;
		empty = true;
	}
	
	CupOfCoffee(String material, int size, boolean empty){
		this.material = material;//2nd one is referring to one right above it
		this.size = size;
		this.empty = empty;
	}
	
	public String toString(){
		String retsrt="";
		
		retsrt="Material: " + this.material + 
				"\nSize: " + this.size +
				"\nEmpty: "+ this.empty + "\n";
		
		return retsrt;
	}
	
	public String getMaterial() {
		return material;
	}

	public void setMaterial(String material) {
		this.material = material;
	}

	public int getSize() {
		return size;
	}

	public void setSize(int size) { //allows you to refer to attributes on the class level
		if (size == 12 || size == 16 || size == 20){
		this.size = size;
		}else{
			System.out.println("Error alert idoit");
		}
	}

	public boolean isEmpty() {
		return empty;
	}

	public void setEmpty(boolean empty) {
		this.empty = empty;
	}

}
