
public class CoffeeOrder {
	 private CupOfCoffee TheOrder[];
	 CoffeeOrder(){
		 this.TheOrder = null;
	 }
	 
	 CoffeeOrder(int n){
		this.TheOrder = new CupOfCoffee[n]; //cardboard carrier + place holder
	 }

	public CupOfCoffee[] getTheOrder() {
		return TheOrder;
	}

	public void setTheOrder(CupOfCoffee[] theOrder) {
		TheOrder = theOrder;
	}
	 
}
