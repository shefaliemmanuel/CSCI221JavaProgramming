import java,io,File;
import java.util.Scanner;
public class Main {

	public static void main(String[] args) throws Exception{
		
/*		CupOfCoffee cup1 = null;
		
		System.out.println(cup1);
		
		cup1= new CupOfCoffee();
	
		//System.out.println(cup1.material);
		//System.out.println(cup1.size);
		//System.out.println(cup1.empty);
		
		cup1= new CupOfCoffee("String", 8, false);
		
		//System.out.println(cup1.material);
		//System.out.println(cup1.size);
		//System.out.println(cup1.empty);

		cup1.size = 16;	
		System.out.println(cup1.size);
		
		cup1.setSize(77);
		System.out.println(cup1.getMaterial());
		System.out.println(cup1.getSize());
		System.out.println(cup1.isEmpty());
		*/
		Scanner shefScanner = new Scanner(new File("input.txt"));
		
		int NumberOfRecords = shefScanner.nextInt();
		shefScanner.nextLine();
		
		CoffeeOrder order1= new CoffeeOrder(NumberOfRecords); //create coffee holder
		
		order1.getTheOrder()[0]= new CupOfCoffee("Plastic", 16, true);
		order1.getTheOrder()[1]= new CupOfCoffee("Concrete", 50, true);
		order1.getTheOrder()[2]= new CupOfCoffee("Recycle", 6, true);
		order1.getTheOrder()[3]= new CupOfCoffee("Ceramic", 67, true);
		
		for(int i=0; i< NumberOfRecords.length;i++){
			String record = shefScanner.nextLine();
			String data[]= record.split(",");
			int size = Interger.parseInt(data[1]);
			boolean empty= Boolean.parseBoolean(data[2]);
			order1.getTheOrder()[i]= new CupOfCoffee(data[0],size,empty);
			System.out.println(order1.getTheOrder()[i]);
		}
		for(int i=0; i< NumberOfRecords; i++){
			System.out.println(order1.getTheOrder()[i]);
		}
	}

}
