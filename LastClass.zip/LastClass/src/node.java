public class node<T> {

	private T data;
	private node<T> next;
	
	
	public node(T data) {
		this.data = data;
		this.next = null;
	}	
	
	public node(T data, node<T> next) {
		super();
		this.data = data;
		this.next = next;
	}
	
	public T getData() {
		return data;
	}
	public void setData(T data) {
		this.data = data;
	}
	public node<T> getNext() {
		return next;
	}
	public void setNext(node<T> next) {
		this.next = next;
	}
	
	
	

	
	
	
	
}
