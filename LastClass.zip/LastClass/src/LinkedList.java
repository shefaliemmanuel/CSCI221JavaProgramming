public class LinkedList<T> {

	private node<T> head;

	public node<T> getHead() {
		return head;
	}

	public void print(){
		// print out all items from head to tail
			node<T> current = this.head;
			while(current != null){
				System.out.println(current.getData());		
				current = current.getNext();
			}	
	}
	
	public void printR(node<T> current){
		// print recursive...
		if(current != null){
			System.out.println(current.getData());	
			printR(current.getNext());
		}
	}
	
	public void printReverse(node<T> current){
		// print recursive...
		if(current != null){
			printReverse(current.getNext());
			System.out.println(current.getData());	
		}
	}

	public T removeFromFront(){
		if(this.head == null){
			return null;
		}else{
			T temp = this.head.getData();
			this.head = this.head.getNext();
			return temp;			
		}
	}
	
	public void addToFront(T item){
		if(this.head == null){
			this.head = new node<T>(item);
		}else{
			node<T> temp = new node<T>(item); // Step 1
			temp.setNext(this.head); // Step 2
			this.head = temp; // Step 3
		}
	}
	
	public void setHead(node<T> head) {
		this.head = head;
	}

	public LinkedList( ) {
		this.head = null;
	}
}
