public class Main {

	public static void main(String[] args) {

		LinkedList<String> L = new LinkedList<String>();
		L.addToFront("Cat");
		L.addToFront("Dog");
		L.addToFront("Pig");
		L.addToFront("Chicken");
		L.printReverse(L.getHead());
		
		System.out.println();
	}

}
