import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class Players {
	
	ArrayList<Player> people = new ArrayList<Player>();
	
	ArrayList<Player> temp = new ArrayList<Player>();
	
	//sort through code to make everything even
	Scanner shefScanner = new Scanner(new File("Master.csv"));
	//BigO(n^2)
	while(shefScanner.hasNext()){
		String record = shefScanner.nextLine();
			//add another bubble sort loop or insertion sort or merger sort(n log n)
		String data[] = record.split(",");
		temp.add(new Person(data[1], data[0])); //this is automatically in order
	}
	shefScanner.close();
	
	Scanner shefScanner = new Scanner(new File("Batting.csv"));
	//BigO(n^2)
	// when delete for loop this becomes (n)
	// total (n log n)
	while(shefScanner.hasNext()){ //n lines
		String record = shefScanner.nextLine();
		//binary search (going from the middle and checking) cuts the array size 1/2 (log n)
		String data[] = record.split(",");
		for (int i=0; i<temp.size;i++){ //m times
			if(data[0].equals(temp.get(i).getID())){ //find the same ID name
				people.add(new Student(temp.get(i).getID(), data[0], data[1], data[2]))
			}
		}
	}
	shefScanner.close();

	Scanner shefScanner = new Scanner(new File("Pitching.csv"));
	
	while(shefScanner.hasNext()){
		String record = shefScanner.nextLine();
		String data[] = record.split(",");
		for (int i=0; i<temp.size;i++){
			if(data[0].equals(temp.get(i).getID())){ //find the same ID name
				people.add(new Student(temp.get(i).getID(), data[0], data[1], data[2]))
			}
		}
	}
	shefScanner.close();
	
	public Players(String PitData, String BatData, String MasterData){
	}
	
	public int getTopBattersSorted(int n){
		return 0; //return an array list of battered
	}
	
	public int getTopPitchersSorted(int n){
		return 0; //ArrayList<Pitcher>
	}
	
	public int getPlayer(String PlayerID){
		return 0; //Player
	}
	
	public int getTopHomerunHittersSorted(int n){
		return 0; //ArrayList<Batter>
	}
	
	public int getLowestERASorted(int n){
		return 0; //ArrayList<Pitcher>
	}

	//toString
	public String toString() {
		return "Players [PitData=" + PitData + ", BatData=" + BatData + ", MasterData=" + MasterData + "]";
	}

	//getters and setters
	String getPitData() {
		return PitData;
	}

	public void setPitData(String pitData) {
		PitData = pitData;
	}

	public String getBatData() {
		return BatData;
	}

	public void setBatData(String batData) {
		BatData = batData;
	}

	public String getMasterData() {
		return MasterData;
	}

	public void setMasterData(String masterData) {
		MasterData = masterData;
	}
}
