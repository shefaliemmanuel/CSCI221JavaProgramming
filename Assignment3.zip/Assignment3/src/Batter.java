import java.io.File;
import java.util.Scanner;

public class Batter extends Player implements Comparable{
	
	private int YearID, HomeRuns, RBI;
	private String TeamID;
	
	Batter(String PlayerID, String FirstName, String LastName, String BirthDate, String BirthLocation, int Height, int Weight, int YearID, String TeamID, int HomeRuns, int RBI){
		super(PlayerID, FirstName, LastName, BirthDate, BirthLocation, Height, Weight);
		this.YearID = YearID;
		this.TeamID = TeamID;
		this.HomeRuns = HomeRuns;
		this.RBI = RBI;
	}
	
	//create an array of Batter
	private Batter BatterInformation[];

	Batter(){
		this.BatterInformation = null;
	}
	
	Batter(String FileName) throws Exception{
		
		Scanner shefScanner = new Scanner(new File(FileName));
		int recordNumber = 0;
		shefScanner.nextLine();
		
		while(shefScanner.hasNext()){
			shefScanner.nextLine();
			recordNumber++;			
		}shefScanner.close();
		
		this.BatterInformation = new Batter[recordNumber];
		shefScanner = new Scanner(new File(FileName));
		shefScanner.nextLine(); 
		
		for(int i = 0;i < recordNumber;++i){
			String record = shefScanner.nextLine();
			String column[] = record.split(",");
			BatterInformation[i] = new Batter(column[0], record, record, record, record, Integer.parseInt(column[1]), i, i, record, i, i);	
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	//toString method
	public String toString() {
		return "Batter [YearID=" + YearID + ", TeamID=" + TeamID + ", HomeRuns=" + HomeRuns + ", RBI=" + RBI + "]";
	}

	//getters + setters
	public int getYearID() {
		return YearID;
	}

	public void setYearID(int yearID) {
		YearID = yearID;
	}

	public String getTeamID() {
		return TeamID;
	}

	public void setTeamID(String teamID) {
		TeamID = teamID;
	}

	public int getHomeRuns() {
		return HomeRuns;
	}

	public void setHomeRuns(int homeRuns) {
		HomeRuns = homeRuns;
	}

	public int getRBI() {
		return RBI;
	}

	public void setRBI(int rBI) {
		RBI = rBI;
	}

	public int compareTo(Object x){
		Batter e = (Batter)x;	
		if(this.RBI == e.RBI){
			if(this.HomeRuns < e.HomeRuns){
				return e.HomeRuns;
			}else{
				return this.HomeRuns;
			}
		}else{
			if(this.RBI < e.RBI){
				return e.RBI;
			}else{
				return this.RBI;
			}
		}	
	}
	
}
