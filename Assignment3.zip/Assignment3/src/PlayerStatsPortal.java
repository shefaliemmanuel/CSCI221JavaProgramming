import java.util.Scanner;

public class PlayerStatsPortal {

	public static void main(String[] args) {

		Scanner shefScanner = new Scanner(System.in);
		Batter myBatters = new Batter();
		Pitcher myPitchers = new Pitcher();
		Player myPlayers = new Player();
		 
		try{
			myBatters = new Batter("Batting.csv");
			myPitchers = new Pitcher("Pitching.csv");
			myPlayers = new Player("Master.csv");
		}catch(Exception e){
			System.out.println(e.getMessage());
			System.exit(0);
		}
		
	}

}
