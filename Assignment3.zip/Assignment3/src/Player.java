import java.io.File;
import java.lang.reflect.Array;
import java.util.Scanner;

public class Player {

	private String PlayerID, FirstName, LastName, BirthDate, BirthLocation;
	private int Height, Weight;
	
	Player(String PlayerID, String FirstName, String LastName, String BirthDate, String BirthLocation, int Height, int Weight){
		this.PlayerID = PlayerID;//2nd one is referring to one right above it
		this.FirstName = FirstName;
		this.LastName = LastName;
		this.BirthDate = BirthDate;
		this.BirthLocation = BirthLocation;
		this.Height = Height;
		this.Weight= Weight;
	}
	
	//create an array of Pitcher
		//private Player PlayerComboInformation[];
		private Player[] PlayerComboInformation = (Player[])Array.addAll(BatterInformation, PitcherInformation);

		Player(){
			this.PlayerComboInformation = null;
		}
		
		Player(Array BatterInformation, Array PitcherInformation) throws Exception{
			
			Scanner shefScanner = new Scanner(new Array(ArrayName, ArrayName));
			//or
			Scanner shefScanner0 = new Scanner(new Array(ArrayName));
			Scanner shefScanner1 = new Scanner(new Array(ArrayName));
			int recordNumber = 0;
			shefScanner.nextLine();
			
			while(shefScanner.hasNext()){
				shefScanner.nextLine();
				recordNumber++;			
			}shefScanner.close();
			
			this.PlayerComboInformation = new Player[recordNumber];
			shefScanner = new Scanner(new Array(ArrayName, ArrayName));
			shefScanner.nextLine(); 
			
			for(int i = 0;i < recordNumber;++i){
				String record = shefScanner.nextLine();
				String column[] = record.split(",");
				PitcherInformation[i] = new Pitcher(record, record, record, record, record, Integer.parseInt(column[0]),i, i, column[1], i, i, ERA);	
			}
		}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	public String toString() {
		return "Player [PlayerID=" + PlayerID + ", FirstName=" + FirstName + ", LastName=" + LastName + ", BirthDate="
				+ BirthDate + ", BirthLocation=" + BirthLocation + ", Height=" + Height + ", Weight=" + Weight + "]";
	}

	public String getPlayerID() {
		return PlayerID;
	}

	public void setPlayerID(String playerID) {
		PlayerID = playerID;
	}

	public String getFirstName() {
		return FirstName;
	}

	public void setFirstName(String firstName) {
		FirstName = firstName;
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		LastName = lastName;
	}

	public String getBirthDate() {
		return BirthDate;
	}

	public void setBirthDate(String birthDate) {
		BirthDate = birthDate;
	}

	public String getBirthLocation() {
		return BirthLocation;
	}

	public void setBirthLocation(String birthLocation) {
		BirthLocation = birthLocation;
	}

	public int getHeight() {
		return Height;
	}

	public void setHeight(int height) {
		Height = height;
	}

	public int getWeight() {
		return Weight;
	}

	public void setWeight(int weight) {
		Weight = weight;
	}

}
