import java.io.File;
import java.util.Scanner;

@SuppressWarnings("rawtypes")
public class Pitcher extends Player implements Comparable{

	private int YearID, Win, Losses;
	private String TeamID;
	private double ERA;
	
	Pitcher(String PlayerID, String FirstName, String LastName, String BirthDate, String BirthLocation, int Height, int Weight, int YearID, String TeamID, int Win, int Losses, double ERA){
		super(PlayerID, FirstName, LastName, BirthDate, BirthLocation, Height, Weight);
		this.YearID =YearID;
		this.TeamID = TeamID;
		this.Win = Win;
		this.Losses = Losses;
		this.ERA = ERA;
	}

	//create an array of Pitcher
	private Pitcher PitcherInformation[];

	Pitcher(){
		this.PitcherInformation = null;
	}
	
	Pitcher(String FileName) throws Exception{
		
		Scanner shefScanner = new Scanner(new File(FileName));
		int recordNumber = 0;
		shefScanner.nextLine();
		
		while(shefScanner.hasNext()){
			shefScanner.nextLine();
			recordNumber++;			
		}shefScanner.close();
		
		this.PitcherInformation = new Pitcher[recordNumber];
		shefScanner = new Scanner(new File(FileName));
		shefScanner.nextLine(); 
		
		for(int i = 0;i < recordNumber;++i){
			String record = shefScanner.nextLine();
			String column[] = record.split(",");
			PitcherInformation[i] = new Pitcher(record, record, record, record, record, Integer.parseInt(column[0]),i, i, column[1], i, i, ERA);	
		}
	}
	
	
	
	

	//toString method
	public String toString() {
		return "Pitcher [YearID=" + YearID + ", Win=" + Win + ", Losses=" + Losses + ", TeamID=" + TeamID + ", ERA="
				+ ERA + "]";
	}

	//getters + setters
	public int getYearID() {
		return YearID;
	}

	public void setYearID(int yearID) {
		YearID = yearID;
	}

	public int getWin() {
		return Win;
	}

	public void setWin(int win) {
		Win = win;
	}

	public int getLosses() {
		return Losses;
	}

	public void setLosses(int losses) {
		Losses = losses;
	}

	public String getTeamID() {
		return TeamID;
	}

	public void setTeamID(String teamID) {
		TeamID = teamID;
	}

	public double getERA() {
		return ERA;
	}

	public void setERA(double eRA) {
		ERA = eRA;
	}

	public int compareTo(Object x){
		Batter e = (Batter)x;	
		if((this.Win - this.Losses) - (e.Win + e.Losses) == 0){
			return 0;
		}else{
			if(this.ERA > e.ERA){
				return e.ERA;
			}else{
				return this.ERA;
			}
		}
	}
}
