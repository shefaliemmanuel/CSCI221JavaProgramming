import java.util.Random;

public class ImageProcessing {

	// Problem 1
	public static short[][] brightenOrDarken(short[][] image, short amount) {
		short newImage[][] = new short[image.length][image[0].length];

		for (int i = 0; i < newImage.length; i++) {
			for (int j = 0; j < newImage[0].length; j++) {
				newImage[i][j] = (short) (image[i][j] + amount);
				if (newImage[i][j] < 0) {
					newImage[i][j] = 0;
				}else if (newImage[i][j] > 255) {
					newImage[i][j] = 255;
				}
			}
		}
		return newImage;
	}

	// Problem 2
	public static short[][] midrange(short[][] image) {
		short newImage[][] = new short[image.length][image[0].length];
		int totalPixel = 0;
		int pixelAverage = 0;
		int imageArea = 0;

		for (int i = 0; i < newImage.length; i++) {
			for (int j = 0; j < newImage[0].length; j++) {
				totalPixel += image[i][j];
			}
		}
		imageArea = image.length * image[0].length;
		pixelAverage = totalPixel / imageArea;

		for (int i = 0; i < newImage.length; i++) {
			for (int j = 0; j < newImage[0].length; j++) {
				newImage[i][j] = (short) (Math.abs((pixelAverage) - (image[i][j])));
			}
		}
		return newImage;
	}

	// Problem 3
	public static short[][] noise(short[][] image, short noise) {
		short newImage[][]= new short[(short) image.length][(short) image[0].length];
		short value = 0;
		Random random1 = new Random();
		int random= random1.nextInt(noise);
		
		for (int i = 0; i < (short) image.length; i++) {
			for (int j = 0; j < (short) image[0].length; j++) {
				if(Math.random() > .5){
					value = -1;
				}else{
					value = 1;
				}
				int nP= (int)(random*value);
				newImage[i][j]= (short)(nP + image[i][j]);
				if(newImage[i][j]<0){
					newImage[i][j]=0;
				}else if(newImage[i][j]>255){
					newImage[i][j]=255;
				}
			}
		}
		return newImage;
	}

	// Problem 4
	public static short[][] crop(short[][] image, int ULy, int ULx, int LRx, int LRy) {
		short newImage[][]= new short [(short)(Math.abs(LRy- ULy))][(short)(Math.abs(LRx- ULx))]; //create a new image with the new dimensions
		
		for(int i=0; i< (short)(Math.abs(LRy- ULy)); i++){
			for(int j=0; j < (short)(Math.abs(LRx- ULx)); j++){
				newImage[i][j]= (short) (Math.abs(image[i+ULy][j+ULx])); //ULy & x bc you're taking the difference then adding it back
			}
		}
		return newImage;
	}

	// Problem 5
	public static short[][] xDir(short[][] image) {
		short newImage[][] = new short[image.length][image[0].length-1];
		for (int i = 0; i < newImage.length; i++) {
			for (int j = 0; j < newImage[0].length; j++) {
				int abs= Math.abs(image[i][j]);
				int absAdd1= Math.abs(image[i][j+1]);
				newImage[i][j]= (short) (abs-absAdd1);
			}
		}
		return newImage;
	}

	// Problem 6
	public static short[][] segment(short[][] image, int low, int high) {
		short newImage[][] = new short[image.length][image[0].length];
		for (int i = 0; i < newImage.length; i++) {
			for (int j = 0; j < newImage[0].length; j++) {
				if (image[i][j] < low) {
					newImage[i][j]= 0;
				} else if (low == image[i][j] || low < image[i][j] && image[i][j] < high) {
					newImage[i][j]= 150;
				} else if (high <= image[i][j]) {
					newImage[i][j]= 255;
				} else {
					break;
				}
			}
		}
		return newImage;
	}

	// Problem 7
	public static short[][] drawBox(short[][] image1, int ULx, int ULy, int LRx, int LRy) { //UL= upper left LR= lower right
		short newImage[][] = new short[(short)image1.length][(short)image1[0].length];
		
		for(int i=0; i< (short)image1.length; i++){
			for(int j=0; j < (short)image1[0].length; j++){
				newImage[i][j]= image1[i][j];
				if(i<=LRy && j==ULx && j>=ULy){
					newImage[i][j]=255;
				}else if(i<=LRy && i>=ULy && j==LRx){
					newImage[i][j]=255;
				}else if(i==LRy && j<=LRx && j>=ULx){
					newImage[i][j]=255;
				}else if(i==ULy && j<=LRx && j>=ULx){
					newImage[i][j]=255;
				}
			}
		}
		return newImage;
	}
}
