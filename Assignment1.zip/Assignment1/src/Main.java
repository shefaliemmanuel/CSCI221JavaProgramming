
public class Main {

	public static void main(String[] args) {
		getPGM pic= new getPGM("football.pgm"); //open up file
		new showGrayImage((pic.getImage()), "Original"); //working
		new showGrayImage(ImageProcessing.brightenOrDarken(pic.getImage(), (short) 100), "Brightness or Darkness 100"); //working
		new showGrayImage(ImageProcessing.midrange(pic.getImage()), "MidRange"); //working
		new showGrayImage(ImageProcessing.noise(pic.getImage(), (short) 100 ), "Noise 100"); //working
		new showGrayImage(ImageProcessing.crop(pic.getImage(), (short) 50, (short) 50,(short) 400,(short) 100 ), "Crop 50, 50, 400, 100");
		new showGrayImage(ImageProcessing.xDir(pic.getImage()), "X Direction Derivative"); //working
		new showGrayImage(ImageProcessing.segment(pic.getImage(), (short) 50, (short) 100), "Segment 50, 100"); //working
		new showGrayImage(ImageProcessing.drawBox(pic.getImage(), (short) 315, (short) 2,(short) 345,(short) 32), "Draw Box 315, 2, 345, 32"); //working
	}
}