import java.util.Scanner;

//import java.util.Scanner;
//import java.util.*;  don't want to bc you want to be as precise as possible


public class fun {

	/**
	 * Javadoc Comments....
	 * 
	 * @param args
	 */
	
	public static void main(String[] args) {
		
		//args= arguments
		//string[] args= string of arguments
		
		
		/*
		 * Very Nice!
		 * 
		 */
		System.out.println("Please enter an interger: ");
		Scanner shefScan = new Scanner(System.in);
		
		boolean found = true;
		
		System.out.println("double = " + found);
	}

}
