
public class Student {
	private int StudentID;
	private String FirstName;
	private String LastName;
	private double Average;
	private String letter;
	
	//constructor has same name as class
	Student(int StudentID, String FirstName, String LastName, double Average, String letter){
		this.StudentID = StudentID;
		this.FirstName = FirstName;
		this.LastName = LastName;
		this.Average = Average; ''
		this.letter = letter;
	}
	
	@Override
	public String toString() {
		return "Student [StudentID=" + StudentID + ", FirstName=" + FirstName + ", LastName=" + LastName + ", Average="
				+ Average + ", letter=" + letter + "]";
	}
	
	public int getStudentID() {
		return StudentID;
	}
	public void setStudentID(int studentID) {
		StudentID = studentID;
	}
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public double getAverage() {
		return Average;
	}
	public void setAverage(double average) {
		Average = average;
	}
	public String getLetter() {
		return letter;
	}
	public void setLetter(String letter) {
		this.letter = letter;
	}
	
}
