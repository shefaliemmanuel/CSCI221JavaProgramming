import java.util.Scanner;

public class Main {
	public static void main(String[] args)throws Exception{
		
		Students myRoll= new Students("students.txt");
		
		Scanner myScanner = new Scanner(System.in);
		while(true){
			System.out.println("Please choose:");
			System.out.println("1 - Print Letter");
			System.out.println("2- Average");
			System.out.println("3 - Look up student id");
			
			int choice = myScan.nextInt();
			if(choice ==1 ){
				Student.printLetter("Which grade would you like to find?");
				myRoll.printLetter(myScanner.next());
			}else if(choice ==2){
				Student.printLetter('A')
			}else{
				Student.printLetter('A')
			}
		}
	System.out.println();
	}
}
