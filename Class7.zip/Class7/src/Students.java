import java.io.File;
import java.util.Scanner;

public class Students {
	private Student Roster[];
	
	Students(){
		//read in the database text file
		//Create array
		//store data
		Scanner myScan = new Scanner(new File(Filename));
		 //determine number of records
		int count =0 ;
		myScan.nextLine(); //discards that first line of header info
		
		while(myScan.hasNext()){
			myScan.nextLine();
			count++;
		}
		myScan.close();
		
		this.Roster = new Student[count];
		
		myScan = new Scanner(new File(Filename));
		myScan.nextLine();
		
		for(int i=0; i < count; i++){
			String reccord = myScan.nextLine();
			String data[]= record.split(',');
			Roster[i]= new Student(Interger,parse(data[0], data[1], data[2], data[3], data[4]))
		}
	}

	public void printLetter(String letter){
		for(int i=0; i < this.Roster.length(); i++){
			if(this.Roster[i].getLetter().equals(letter)){
				System.out.print(this.Roster[i]);
			}
		}
	}
	
	public Student[] getRoster() {
		return Roster;
	}

	public void setRoster(Student[] roster) {
		Roster = roster;
	}
	
	
}
