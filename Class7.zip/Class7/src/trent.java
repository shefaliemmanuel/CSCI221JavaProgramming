
public class trent {
	// same
		for(String i: args){
			
		}
		for (int i=0; i< args.length; i++){
			
		}
		
	//3rd grader
		HashMap<String, Interger> map = new HashMap<String.Interger>();
		map.put("AB", 3);
		Math.hypot(map.get("AB"), map.get("BC"));
		
	
}
