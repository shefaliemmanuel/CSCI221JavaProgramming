
public class LinkedList {

}
