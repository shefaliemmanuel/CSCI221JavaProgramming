import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

public class Players{

    private ArrayList <Player> Roster;
    private String PitData, BatData, MasterData;

    //default constructors 
    public Players(){ 
        PitData = "Pitching.csv";
        BatData = "Batting.csv";
        MasterData = "Master.csv";
    }

    //constructors
    public Players(String pitData, String batData, String masterData){
        PitData = pitData;
        BatData = batData;
        MasterData = masterData;
    }

    //getters && setters
    public String getPitData(){
        return PitData;
    }

    public void setPitData(String pitData){
        PitData = pitData;
    }

    public String getBatData(){
        return BatData;
    }

    public void setBatData(String batData){
        BatData = batData;
    }

    public String getMasterData(){
        return MasterData;
    }

    public void setMasterData(String masterData){
        MasterData = masterData;
    }

    public String toString() {
        return "Players:" +"Roster= " + Roster + '\n' +", PitData= '" + PitData + '\n' +", BatData= '" + BatData + '\n' +
                ", MasterData= '" + MasterData + '\n';
    }
    //batters
    public static ArrayList <Batter> getBattersAsList(String fileLocation) throws Exception {
    	//scan file in
        Scanner myScan = new Scanner(new File(fileLocation));
        //create array list
        ArrayList <Batter> BattArrList = new ArrayList<>();
        //cut list 
        while(myScan.hasNext()){
            String record = myScan.nextLine();
            String data[] = record.split(",");
            for(int i = 0; i < data.length; ++i){
                if(data[i].equals("")){
                    data[i]="0";
                }
            }
            if(!data[0].equalsIgnoreCase("playerID")){
                Batter batter = new Batter(Integer.parseInt(data[1]), data[3], Integer.parseInt(data[11]), Integer.parseInt(data[12]));
                batter.setPlayerID(data[0]);
                BattArrList.add(batter);
            }
        }
        myScan.close();
        return BattArrList;
    }
    
    //pitchers
    public static ArrayList <Pitcher> getPitchersAsList(String fileLocation) throws Exception {
    	//scan in file
        Scanner myScan = new Scanner(new File(fileLocation));
        //create an array list
        ArrayList <Pitcher> pitcherArrayList = new ArrayList<>();
        //cut list
        while(myScan.hasNext()){
            String record = myScan.nextLine();
            String data[] = record.split(",");
            for(int i = 0; i < data.length; ++i){
                if(data[i].equals("")){
                    data[i] = "0";
                }
            }
            if(!data[0].equalsIgnoreCase("playerID")){
                Pitcher pitcher = new Pitcher(Integer.parseInt(data[1]), data[3], Integer.parseInt(data[5]), Integer.parseInt(data[6]), Double.parseDouble(data[19]));
                pitcher.setPlayerID(data[0]);
                pitcherArrayList.add(pitcher);
            }
        }
        myScan.close();
        return pitcherArrayList;
    }

    //player
    public static ArrayList <Player> getPlayersAsList(String fileLocation) throws Exception {
    	//scan in file
        Scanner myScan = new Scanner(new File(fileLocation));
        //create an array list
        ArrayList <Player> playerArrayList = new ArrayList<>();
        //cut list
        while(myScan.hasNext()){
            String record = myScan.nextLine();
            String data[] = record.split(",");
            for(int i = 0; i < data.length; ++i){
                if(data[i].equals("")){
                    data[i] = "0";
                }
            }
            if(!data[0].equalsIgnoreCase("playerID")){

                if(data.length<23){   
                    String[] newData = new String[23];
                    for(int y = 0; y < data.length; ++y){
                        newData[y] = data[y];
                    }
                    data = newData;
                }
                if(data[13].equals(" ") || data[13].equals("")){   
                    data[13] = "Empty";
                }else if(data[14].equals(" ") || data[14].equals("")){ 
                    data[14] = "Empty";
                }else if(data[16] == null){ 
                    data[16] = "Empty";
                }else if(data[17] == null){ 
                    data[17] = "Empty";
                }

                Player player = new Player(data[0], data[13], data[14],data[1] + "/" + data[2] + "/" + data[3], data[6], Integer.parseInt(data[17]), Integer.parseInt(data[16]));
                playerArrayList.add(player);
            }
        }
        myScan.close();
        return playerArrayList;
    }

    public ArrayList <Batter> getTopBattersSorted(int number) throws Exception{
        ArrayList <Batter> BattArr = getBattersAsList(BatData);
        
        //create variables
        float grandTotal = BattArr.size();
        float amount;
        
        for (int i = 0; i < BattArr.size()-1; ++i){
            amount = (100 * i) / grandTotal;     
            
            //print statement
            System.out.print(String.format("Complete ", amount)); 
            
            //size -1
            for (int j = 0; j < (BattArr.size() - 1) - i; ++j) {
                if (BattArr.get(j).compareTo(BattArr.get(j + 1)) < 0){
                    Batter tempCounter = BattArr.get(j);
                    BattArr.set(j, BattArr.get(j + 1));
                    BattArr.set(j + 1, tempCounter);
                }
            }
        }
        
        ArrayList <Batter> BattArrSorted = new ArrayList<>();
        for(int i = 0; i < number; ++i){
            BattArrSorted.add(BattArr.get(i));
        }
        return BattArrSorted;
    }

    public ArrayList <Pitcher> getTopPitchersSorted(int number) throws Exception{ 
        ArrayList <Pitcher> PitcherArray = getPitchersAsList(PitData);
        
        //create variables
        float amount;
        float grandTotal = PitcherArray.size();
        
        for (int i = 0; i < PitcherArray.size()-1; ++i){
            amount = (100 * i) / grandTotal;
            
            //print statement
            System.out.print(String.format("Complete   ", amount));
            
            //size -1
            for (int j = 0; j < (PitcherArray.size() - 1) - i; ++j){
                if (PitcherArray.get(j).compareTo(PitcherArray.get(j + 1)) < 0){
                    Pitcher tempCounter = PitcherArray.get(j);
                    PitcherArray.set(j, PitcherArray.get(j + 1));
                    PitcherArray.set(j + 1, tempCounter);
                }
            }
        }
        ArrayList <Pitcher> pitcherArraySorted = new ArrayList<>();
        for(int i = 0; i < number; ++i){
            pitcherArraySorted.add(PitcherArray.get(i));
        }
        return pitcherArraySorted;
    }

    public Player getPlayer(String PlayerID) throws Exception{
    	
        ArrayList <Player> PlayersList = getPlayersAsList(MasterData);
        //size -1
        for (int i = 0; i < PlayersList.size() - 1; ++i) {
            if(PlayersList.get(i).getPlayerID().equalsIgnoreCase(PlayerID)){ 
                return PlayersList.get(i);
            }
        }
        return null;
    }

    public ArrayList <Batter> getTopHomerunHittersSorted(int number) throws Exception{
        ArrayList <Batter> BattArr = getBattersAsList(BatData);
        
        //create variables
        float amount;
        float grandTotal = BattArr.size();
        
        for (int i = 0; i < BattArr.size() - 1; ++i) {
            amount = (100 * i) / grandTotal;
            System.out.print(String.format("Complete",amount));
            for (int j = 0; j < (BattArr.size() - 1) - i; ++j) {
                if (BattArr.get(j).compareToHr(BattArr.get(j + 1)) < 0) {
                    Batter tempCounter = BattArr.get(j);
                    BattArr.set(j, BattArr.get(j + 1));
                    BattArr.set(j + 1, tempCounter);
                }
            }
        }
        ArrayList <Batter> BattArrSorted = new ArrayList<>();
        for(int i = 0; i < number; ++i){
            BattArrSorted.add(BattArr.get(i));
        }
        return BattArrSorted;
    }

    public ArrayList <Pitcher> getLowestERASorted(int number) throws Exception{
        ArrayList<Pitcher> PitcherArray = getPitchersAsList(PitData);
        
      //create variables
        float amount;
        float grandTotal = PitcherArray.size();
        // size -1 (not length)
        for (int i = 0; i < PitcherArray.size() - 1; ++i) {
            amount = (100 * i) / grandTotal;
            
            System.out.print(String.format("Complete ",amount));
            
            for (int j = 0; j < (PitcherArray.size() - 1) - i; ++j) {
                if (PitcherArray.get(j).compareToERA(PitcherArray.get(j + 1)) > 0) {
                    Pitcher tempCounter = PitcherArray.get(j);
                    PitcherArray.set(j, PitcherArray.get(j + 1));
                    PitcherArray.set(j + 1, tempCounter);
                }
            }
        }
      //create array list 
        ArrayList <Pitcher> pitcherArraySorted = new ArrayList<>();
        for(int i =0; i<number; ++i){
            pitcherArraySorted.add(PitcherArray.get(i));
        }
        return pitcherArraySorted;
    }
}
