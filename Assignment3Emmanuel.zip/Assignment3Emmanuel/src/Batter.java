public class Batter extends Player implements Comparable {

	//attributes
    private int YearID, HomeRuns, RBI;
    private String TeamID;

    //default constructor 
    public Batter(){  
        super();
        this.YearID = 0;
        this.TeamID = null;
        this.HomeRuns = 0;
        this.RBI = 0;
    }

    //constructor
    public Batter(int yearID, String teamID, int homeRuns, int rbi) {
        super();
        this.YearID = yearID;
        this.TeamID = teamID;
        this.HomeRuns = homeRuns;
        this.RBI = rbi;
    }
    
    //toString
    public String toString(){
        return "Batter:" + "PlayerID = "+ this.getPlayerID()+ ", YearID = " + YearID + ", TeamID = " + TeamID +
                ", HomeRuns = " + HomeRuns +", RBI = " + RBI;
    }

    //getters && setters
    public int getYearID(){
        return YearID;
    }

    public void setYearID(int yearID){
        YearID = yearID;
    }

    public String getTeamID(){
        return TeamID;
    }
    public void setTeamID(String teamID){
        TeamID = teamID;
    }

    public int getHomeRuns(){
        return HomeRuns;
    }
    public void setHomeRuns(int homeRuns){
        HomeRuns = homeRuns;
    }

    public int getRBI(){
        return RBI;
    }

    public void setRBI(int RBI) {
        this.RBI = RBI;
    }
    
    // HomeRuns
    public int compareToHr(Object y){
    	if(this.getHomeRuns() > ((Batter) y).getHomeRuns()){ 
            return 1;
    	} else if(this.getHomeRuns() == ((Batter) y).getHomeRuns()){  
            return 0; 
        }
        else {  
            return -1;
        }
    }

    public int compareTo(Object y){
        if(this.getRBI() == ((Batter) y).getRBI()){  
        	if(this.getHomeRuns() > ((Batter) y).getHomeRuns()){ 
                return 1;
        	} else if(this.getHomeRuns() == ((Batter) y).getHomeRuns()){
                return 0;
            }
            else {
                return -1;
            }
        }
        else if(this.getRBI() > ((Batter) y).getRBI()) {
            return 1;
        }
        else {
            return -1;
        }
    }
}
