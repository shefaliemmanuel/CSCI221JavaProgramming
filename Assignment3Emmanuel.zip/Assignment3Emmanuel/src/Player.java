public class Player{

	//attributes
    private String PlayerID, FirstName, LastName, BirthDate,BirthLocation;
    private int Height, Weight;

	//default constructor
    public Player(){
        this.PlayerID = null;
        this.FirstName = null;
        this.LastName = null;
        this.BirthDate = null;
        this.BirthLocation = null;
        this.Height = 0;
        this.Weight = 0;
    }

    //constructor
    public Player(String playerID, String firstName, String lastName, String birthDate, String birthLocation, int height, int weight){
        PlayerID = playerID;
        FirstName = firstName;
        LastName = lastName;
        BirthDate = birthDate;
        BirthLocation = birthLocation;
        Height = height;
        Weight = weight;
    }

    //to string
    public String toString() {
        return "Player:" + "PlayerID = '" + PlayerID + '\'' + ", FirstName = '" + FirstName + '\'' +
                ", LastName = '" + LastName + '\'' + ", BirthDate = '" + BirthDate + '\'' +
                ", BirthLocation ='" + BirthLocation + '\'' + ", Height = " + Height + ", Weight = " + Weight;
    }
    
    //getters && setters
    public String getPlayerID(){
        return PlayerID;
    }
    public void setPlayerID(String playerID){
        PlayerID = playerID;
    }

    public String getFirstName(){
        return FirstName;
    }
    public void setFirstName(String firstName){
        FirstName = firstName;
    }

    public String getLastName(){
        return LastName;
    }
    public void setLastName(String lastName){
        LastName = lastName;
    }

    public String getBirthDate(){
        return BirthDate;
    }
    public void setBirthDate(String birthDate){
        BirthDate = birthDate;
    }

    public String getBirthLocation(){
        return BirthLocation;
    }
    public void setBirthLocation(String birthLocation){
        BirthLocation = birthLocation;
    }

    public int getHeight(){
        return Height;
    }
    public void setHeight(int height){
        Height = height;
    }

    public int getWeight(){
        return Weight;
    }
    public void setWeight(int weight){
        Weight = weight;
    }
}
