import java.util.Scanner;

public class PlayerStatsPortal {

    public static void main(String[] args) throws Exception{

        try{
        Players playersData = new Players("Pitching.csv","Batting.csv","Master.csv");

        while(true){
    		System.out.println("The Player Statistics Portal");
    		System.out.println("Enter a Number:");
    		System.out.println();
    		System.out.println("O. Quit Program");
    		System.out.println("1. Top Batters");
    		System.out.println("2. Top Pitchers");
    		System.out.println("3. Find a Player with ID");
    		System.out.println("4. Top HomeRun Hitters");
    		System.out.println("5. Lowest ERA's");
    		System.out.println();

    		Scanner shefScanner = new Scanner(System.in);
    		int entered = shefScanner.nextInt();
            int enteredNum;
            String enteredStr;
  
            if(entered == 0) {
                System.out.println("Quitting");
                break;
                
           }else if(entered == 1){
               System.out.println("Enter the Number of Batters you would like displayed:");
               enteredNum = shefScanner.nextInt();
               System.out.println("Top " + enteredNum + " Batters are: ");
               System.out.print(playersData.getTopBattersSorted(enteredNum));
               
            }else if(entered == 2) {
                System.out.println("Enter the Number of Pitchers you would like displayed:");
                enteredNum = shefScanner.nextInt();
                System.out.println("Top " + enteredNum + " Pitchers are: ");
                System.out.print(playersData.getTopPitchersSorted(enteredNum));

            }else if(entered == 3) {
                System.out.println("Enter PlayerID:");
                enteredStr = shefScanner.next();
                System.out.println("Becomes: " + (playersData.getPlayer(enteredStr)));

            }else if(entered == 4) {
                System.out.println("Enter the Number of Home Run Hitters you would like displayed: ");
                enteredNum = shefScanner.nextInt();
                System.out.println(enteredNum + " HomeRun Hitters: ");
                System.out.println(playersData.getTopHomerunHittersSorted(enteredNum));

            }else if(entered == 5) {
                System.out.println("Enter the Number of pitchers for ERA you would like displayed: ");
                enteredNum = shefScanner.nextInt();
                System.out.println("Lowest" + enteredNum + " ERA players: ");
                System.out.print(playersData.getLowestERASorted(enteredNum));

            }else{
                System.out.println("Please enter a valid number.");
            }
        }
        }catch(Exception e){
            System.out.println("you failed");
            main(null);
        }
    }
}