public class Pitcher extends Player implements Comparable{

	//attributes
    private int YearID, Wins, Losses;
    private String TeamID;
    private Double ERA;

    //default constructor
    public Pitcher(){
        super();
        this.YearID =0;
        this.TeamID=null;
        this.Wins=0;
        this.Losses=0;
        this.ERA=0.0;
    }

    //constructor
    public Pitcher(int yearID, String teamID, int wins, int losses, Double era){
        super();
        YearID = yearID;
        TeamID = teamID;
        Wins = wins;
        Losses = losses;
        ERA = era;
    }

  //constructor
    public Pitcher(String playerID, String firstName, String lastName, String birthDate, String birthLocation, int height, int weight, int yearID, String teamID, int wins, int losses, Double era) {
        super(playerID, firstName, lastName, birthDate, birthLocation, height, weight);
        YearID = yearID;
        TeamID = teamID;
        Wins = wins;
        Losses = losses;
        ERA = era;
    }

    //to String
    public String toString() {
        return "Pitcher:" +"PlayerID = "+this.getPlayerID()+", YearID = " + YearID +", TeamID = " + TeamID +
                ", Wins = " + Wins +", Losses = " + Losses +", ERA = " + ERA;
    }

    //getters && setters
    public int getYearID(){
        return YearID;
    }

    public void setYearID(int yearID){
        YearID = yearID;
    }

    public String getTeamID(){
        return TeamID;
    }

    public void setTeamID(String teamID){
        TeamID = teamID;
    }

    public int getWins(){
        return Wins;
    }

    public void setWins(int wins){
        Wins = wins;
    }

    public int getLosses(){
        return Losses;
    }

    public void setLosses(int losses){
        Losses = losses;
    }

    public Double getERA(){
        return ERA;
    }

    public void setERA(Double ERA){
        this.ERA = ERA;
    }

    public int compareToERA(Object y) {
    	if(this.getERA() > ((Pitcher) y).getERA()){
            return 1;
        }else if(this.getERA().equals(((Pitcher) y).getERA())){
            return 0;
        }else {
            return -1;
        }
    }
    
    public int compareTo(Object y) {
        Pitcher x = (Pitcher) y;
        int thatWinsLoss = x.getWins()-x.getLosses();
        int thisWinsLoss = this.getWins()-this.getLosses();
        

        if(thisWinsLoss > thatWinsLoss) {
            return 1;
        }else if(thisWinsLoss == thatWinsLoss){ 
        	if(this.getERA() > ((Pitcher) y).getERA()){ 
                return 1;
            } else if(this.getERA().equals(((Pitcher) y).getERA())){  
                return 0;
            }else { 
                return -1;
            }
        }else {
            return -1;
        }
    }
}
