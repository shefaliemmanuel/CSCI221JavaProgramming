import java.io.File;
import java.util.Scanner;

public class Students {

	private Student Roster[];

	Students(){
		this.Roster = null;
	}
	
	Students(String FileName) throws Exception{
		
		Scanner shefScan = new Scanner(new File(FileName));
		
		int count = 0;
		shefScan.nextLine(); // discards that first line of header info
		
		while(shefScan.hasNext()){
			shefScan.nextLine();
			count++;			
		}
		shefScan.close();
		
		this.Roster = new Student[count];
		
		shefScan = new Scanner(new File(FileName));
		shefScan.nextLine(); // discards that first line of header info
		
		for(int i = 0;i < count;++i){
			String record = shefScan.nextLine();
			String data[] = record.split(",");
			Roster[i] = new Student(Integer.parseInt(data[0]), data[1], data[2], Double.parseDouble(data[3]), data[4]);	
		}
	}
	
	public void printLetter(String letter){
		
		for(int i = 0;i < this.Roster.length;++i){
			if(this.Roster[i].getLetter().equals(letter)){
				System.out.println(this.Roster[i]);
			}
		}		
	}
	public double classAverage(){
		double total = 0.0;
		for(int i=0; i<this.Roster.length; i++){
			total+=this.Roster[i].getAverage();
		}
		return total/this.Roster.length;
	}
	
	public Student lookUpStudentID(int id) throws StudentNotFoundException{
		for(int i = 0; i < this.Roster.length; i++){
			if(Roster[i].getStudentID() == id){
				return Roster[i];
			}
		}
		throw new StudentNotFoundException();
	}
	
	public Student[] getRoster() {
		return Roster;
	}

	public void setRoster(Student[] roster) {
		Roster = roster;
	}	
}