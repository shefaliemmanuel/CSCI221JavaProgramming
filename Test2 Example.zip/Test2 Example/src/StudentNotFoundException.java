
public class StudentNotFoundException extends Exception{

	
	public String getMessage(){
		
		
		return "whomp, whomp, whomp....";
	}
	
	
}
