
public class Student {

		//attributes
		private int StudentID;
		private String FirstName;
		private String LastName;
		private Double Average;
		private String Letter;
		
		//constructor
		Student(int StudentID, String FirstName, String LastName, Double Average, String Letter){
			this.StudentID = StudentID;
			this.FirstName = FirstName;
			this.LastName = LastName;
			this.Average = Average;
			this.Letter = Letter;
		}
		
		public String toString() {
			return "Student [StudentID=" + StudentID + ", FirstName=" + FirstName + ", LastName=" + LastName
					+ ", Average=" + Average + ", Letter=" + Letter + "]";
		}

		public int getStudentID() {
			return StudentID;
		}

		public void setStudentID(int studentID) {
			StudentID = studentID;
		}

		public String getFirstName() {
			return FirstName;
		}

		public void setFirstName(String firstName) {
			FirstName = firstName;
		}

		public String getLastName() {
			return LastName;
		}

		public void setLastName(String lastName) {
			LastName = lastName;
		}

		public Double getAverage() {
			return Average;
		}

		public void setAverage(Double average) {
			Average = average;
		}

		public String getLetter() {
			return Letter;
		}

		public void setLetter(String letter) {
			Letter = letter;
		}
}
