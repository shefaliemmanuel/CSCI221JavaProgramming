import java.util.Scanner;

public class Main {

	public static void main(String[] args){

		Students myRoll = new Students();
		
		try{
			myRoll = new Students("student.txt");
		}catch(Exception e){
			System.out.println(e.getMessage());
			System.exit(0);
		}
		
		Scanner myScan = new Scanner(System.in);
		
		while(true){
			System.out.println("Please choose:");
			System.out.println("1 - Print Letter");
			System.out.println("2 - Class Average");
			System.out.println("3 - Look Up Student ID");
			
			int choice = myScan.nextInt();
			if(choice == 1){
				System.out.println("Which grade would you like to find?");
				myRoll.printLetter(myScan.next());
			}else if(choice == 2){
				System.out.println(myRoll.classAverage());
			}else{
				System.out.println("Please enter the student's ID :)");
				
			try{	
				System.out.println(myRoll.lookUpStudentID(myScan.nextInt()));
			}catch(StudentNotFoundException e){
				System.out.println(e.getMessage());
			}
			}	
		}
	}
}
