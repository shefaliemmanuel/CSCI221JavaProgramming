
public class class4 {

	public static void main(String[] args) {
		//RECURSION
		int div(int a, int b){
			//return a/b
			
			if(a<b){
				return 0; //interger division
			}
			else{
				return 1 + div(a-b,b);
			}
		}
		
		int mod(int a, int b){
			// return a % b
			if(a<b){
				return a;
			}
			else{
				return mod(a-b,b);
			}
		}
		
		printChar("TacoBell");
	}
		 //write a methord that takes a sring argument and prints each character in that string
		//NON Tail Recursion
		public static void printChar(String str){
			
			if(str.length() == 0){
				return 0;
			}
			else{
				System.out.println(str.charAt(0));
				printChar(str.substring(0, str.length()));
				
				//switch these 2 to print reverse
			}
			
		}
	

}
