//generics
public class Practice<T> {

	private T data;
	private String name;
	// ....
	// ....
	public Practice(T data, String name) {
		this.data = data;
		this.name = name;
	}	
	
	public Practice() {
		this.data = null;
		this.name = "default";
	}
	
	
	
}
