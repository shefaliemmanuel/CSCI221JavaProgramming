
public class Student extends Person implements Comparable{

	//ATTRIBUTE
	private int grade, performance;
	
	public Student() {
		super();
		this.grade = 0;
		this.performance = 0;
	}	
	
	public Student(String name, int grade, int performance) {
		super(name);
		this.grade = grade;
		this.performance = performance;
	}

	public int getGrade() {
		return grade;
	}

	public void setGrade(int grade) {
		this.grade = grade;
	}

	public int getPerformance() {
		return performance;
	}

	public void setPerformance(int performance) {
		this.performance = performance;
	}

	public int compareTo(Object x) {
		Student s = (Student)x;
		return (this.grade+this.performance)/2 - (s.grade+s.performance)/2;
	}
	
}
