import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws Exception{

		/*	
			Practice<Integer> temp = new Practice<Integer>(15, "Bob");
			Practice<String> temp2 = new Practice<String>("fun", "Bob");
			Practice<Person> temp3 = new Practice<Person>(new Person("Steve"), "Bob");
		*/
		
		ArrayList<Person> people = new ArrayList<Person>();
		
		ArrayList<Person> temp = new ArrayList<Person>(); //array list of person objects
		
		Scanner myScan = new Scanner(new File("Person.txt"));
		//BigO(n^2)
		while(myScan.hasNext()){
			String record = myScan.nextLine();
				//add another bubble sort loop or insertion sort or merger sort(n log n)
			String data[] = record.split(",");
			temp.add(new Person(data[1], data[0])); //this is automatically in order
		}
		myScan.close();
		
		Scanner myScan = new Scanner(new File("Student.txt"));
		//BigO(n^2)
		// when delete for loop this becomes (n)
		// total (n log n)
		while(myScan.hasNext()){ //n lines
			String record = myScan.nextLine();
			//binary search (going from the middle and checking) cuts the array size 1/2 (log n)
			String data[] = record.split(",");
			for (int i=0; i<temp.size;i++){ //m times
				if(data[0].equals(temp.get(i).getID())){ //find the same ID name
					people.add(new Student(temp.get(i).getID(), data[0], data[1], data[2]))
				}
			}
		}
		myScan.close();

		Scanner myScan = new Scanner(new File("Employee.txt"));
		
		while(myScan.hasNext()){
			String record = myScan.nextLine();
			String data[] = record.split(",");
			for (int i=0; i<temp.size;i++){
				if(data[0].equals(temp.get(i).getID())){ //find the same ID name
					people.add(new Student(temp.get(i).getID(), data[0], data[1], data[2]))
				}
			}
		}
		myScan.close();
		
		/*inserts them in order
		 * ArrayList<Person> people = new ArrayList<Person>();
		 * Student[] s = new Student[4];
		
		s[0] = new Student("Bob", 99, 90);
		s[1] = new Student("Sue", 67, 90);
		s[2] = new Student("Joe", 80, 78);
		s[3] = new Student("Ralph", 45, 90);

		// Insert these items in order into the ArrayList:
		
		for(int i = 0; i < 4;++i){
			
			boolean inserted = false;
			while(!inserted){
				for(int j = 0;j < people.size();++j){
					if(s[i].compareTo(people.get(j)) < 0){
						people.add(j, s[i]);
						inserted = true;
						break;
					}	
				}	
				if(!inserted){
					people.add(people.size(), s[i]);
					inserted = true;
				}
			}
		}*/
		
		System.out.println();
	}

}
