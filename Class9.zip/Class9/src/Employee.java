
public class Employee extends Person implements Comparable{

	//ATTRIBUTE
	private int performance, onTime;

	public Employee(String name, int performance, int onTime) {
		super(name);
		this.performance = performance;
		this.onTime = onTime;
	}

	public int getPerformance() {
		return performance;
	}

	public void setPerformance(int performance) {
		this.performance = performance;
	}

	public int getOnTime() {
		return onTime;
	}

	public void setOnTime(int onTime) {
		this.onTime = onTime;
	}

	public int compareTo(Object x){
		Employee e = (Employee)x;		
		return (this.onTime+this.performance)/2 - (e.onTime+e.performance)/2;	
	}
}
