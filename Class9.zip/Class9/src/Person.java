
public class Person {

	//ATTRIBUTE
	private String name, ID;

	public String getID() {
		return ID;
	}

	public void setID(String iD) {
		ID = iD;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Person() {
		this.name = "nobody";
	}	
	
	public Person(String name, String ID) {
		super();
		this.name = name;
		this.ID = ID;
	}
}
