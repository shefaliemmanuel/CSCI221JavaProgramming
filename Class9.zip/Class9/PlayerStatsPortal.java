import java.util.Scanner;

public class PlayerStatsPortal {
	

	public static void main(String[] args) throws Exception {
		Players Roster = new Players("Pitching.csv", "Batting.csv", "Master.csv");
		
		System.out.println("_________________________________________________________________");
		System.out.println("|" + "\tWelcome to the Player Statistics Portal!\t" + "\t|");
		System.out.println("|" + "\t\tWhat would you like to do?\t" + "\t\t|");
		System.out.println("|" + "--------------------------------------------------------------" + " |");
		System.out.println("|" + "\tPress 1 to find the top 25 batters." + "\t\t\t|");
		System.out.println("|" + "\tPress 2 to find the top 25 pitchers." + "\t\t\t|");
		System.out.println("|" + "\tPress 3 to find a player from their ID." + "\t\t\t|");
		System.out.println("|" + "\tPress 4 to find the top homerun hitters." + "\t\t|");
		System.out.println("|" + "\tPress 5 to find the lowest ERA's." + "\t\t\t|");
		System.out.println("|\t\t\t\t\t\t\t\t|");
		System.out.println("|" + "\tPress 0 to quit." + "\t\t\t\t\t|");
		System.out.println("_________________________________________________________________");

		Scanner myScan = new Scanner(System.in);

		int usrInput = myScan.nextInt();

		boolean contRunning = true;

		while (contRunning) {
			if (usrInput == 0) {
				contRunning = false;
				break;
				
			} else if (usrInput == 1) {
				myScan = new Scanner(System.in);
				System.out.println("How many batters would you like to display?");
				int n = myScan.nextInt();
				System.out.println("The top " +n+ " batters in the roster are: ");
				System.out.println(Roster.getTopBattersSorted(n));
				if(myScan.nextInt() == 0){
					break;
				}
				
			} else if (usrInput == 2) {
				myScan = new Scanner(System.in);
				System.out.println("How many pitchers would you like to display?");
				int n = myScan.nextInt();
				System.out.println();
				System.out.println("The top " +n+ " pitchers in the roster are: ");
				System.out.println(Roster.getTopPitchersSorted(usrInput));
				if(myScan.nextInt() == 0){
					break;
				}
				
			} else if (usrInput == 3) {
				myScan = new Scanner(System.in);
				System.out.println("Please enter the ID of the player you are searching for: ");
				String PlayerID = myScan.nextLine();
				System.out.println(Roster.getPlayer(PlayerID));
				if(myScan.nextInt() == 0){
					break;
				}
				
			} else if (usrInput == 4) {

			} else if (usrInput == 5) {
			}
		}
		myScan.close();

	}

}
