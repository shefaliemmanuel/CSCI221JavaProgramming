import java.io.File;
import java.util.Scanner;

public class PlayerSalaries {

	private PlayerSalary Information[];

	PlayerSalaries(){
		this.Information = null;
	}
	
	PlayerSalaries(String FileName) throws Exception{
		
		Scanner shefScanner = new Scanner(new File(FileName));
		int recordNumber = 0;
		shefScanner.nextLine();
		
		while(shefScanner.hasNext()){
			shefScanner.nextLine();
			recordNumber++;			
		}shefScanner.close();
		
		this.Information = new PlayerSalary[recordNumber];
		shefScanner = new Scanner(new File(FileName));
		shefScanner.nextLine(); 
		
		for(int i = 0;i < recordNumber;++i){
			String record = shefScanner.nextLine();
			String column[] = record.split(",");
			Information[i] = new PlayerSalary(Integer.parseInt(column[0]), column[1], column[2], column[3], Integer.parseInt(column[4]));	
		}
	}
	
	public int averageSalaryInYear (int year){
		int values = 0;
		long sum = 0;
		
		for(int i=0; i < this.Information.length; ++i){
			if(this.Information[i].getYearID() == year){
				sum += this.Information[i].getSalary();
				values++;
			}
		}
	return (int) (sum/ values);
	}
	public PlayerSalary findPlayerInYear(String player, int year){
		
		for(int i = 0; i < this.Information.length; i++){
			if(this.Information[i].getYearID()== year && this.Information[i].getPlayerID().equals(player) ){
					return this.Information[i];
			}
		}
		return null;
	}

	public PlayerSalary highestSalaryInYear(int year) {

		int now;
		int largest = 0;
		PlayerSalary nowSalary;
		PlayerSalary highestSalary = null;
		
		for(int i = 0; i < this.Information.length; i++){
			if(this.Information[i].getYearID()==year){
				now = this.Information[i].getSalary();
				nowSalary = this.Information[i];
				
				int initial = 0;
				PlayerSalary initialSalary = null;
				
				if(initial > now && initial > largest){
					highestSalary = initialSalary;
					largest = initial;
				}else if (initial < now && now > largest){
					highestSalary = nowSalary; 
					largest = now;
				}else{ 
				initial = now;
				initialSalary = nowSalary;
				}
			}
		}
		return highestSalary;
	}
	
	public PlayerSalary lowestSalaryInYear(int year){

		int lowest = 0;
		int now;
		PlayerSalary lowestSalary = null;
		PlayerSalary nowSalary;
		
		for(int i = 0; i < this.Information.length; i++){
			if(this.Information[i].getYearID()==year){
				now = this.Information[i].getSalary();
				nowSalary = this.Information[i];
				
				int initial = 0;
				PlayerSalary initialSalary = null;
				
				if(initial == 0 && lowest ==0){
					initial = now;
					initialSalary = nowSalary;
					lowest = now;
					lowestSalary = nowSalary;
				}else if(initial > now && initial < lowest){
					lowest = initial;
					lowestSalary = initialSalary;
				}else if (initial > now && now < lowest){
					lowest = now;
					lowestSalary = nowSalary; 
				}else{
					initial = now;
					initialSalary = nowSalary;
				}
			}
		}
		return lowestSalary;
	}
	
	public PlayerSalary highestSalaryInTeamInYear(String team, int year){
		int now;
		int largest = 0;
		PlayerSalary nowSalary;
		PlayerSalary highestSalary = null;
		
		for(int i = 0; i < this.Information.length; i++){
			if(this.Information[i].getTeamID().equals(team) && this.Information[i].getYearID()==year){
				now = this.Information[i].getSalary();
				nowSalary = this.Information[i];
				
				int initial =0;
				PlayerSalary initialSalary = null;
				
				if(initial > now && initial > largest){
					largest = initial;
					highestSalary = initialSalary;
				}else if (initial < now && now > largest){
					largest = now;
					highestSalary = nowSalary;
				}else{ 
				initialSalary = nowSalary;
				initial = now;
				}
			}
		}
		return highestSalary;
	}
	
	public PlayerSalary lowestSalaryInTeamInYear(String team, int year){
		
		int lowest = 0;
		int now;
		PlayerSalary nowSalary;
		PlayerSalary lowestSalary = null;
		
		for(int i = 0; i < this.Information.length; i++){
			if(this.Information[i].getYearID()==year && this.Information[i].getTeamID().equals(team) ){
				
				now = this.Information[i].getSalary();
				nowSalary = this.Information[i];
				
				int initial = 0;
				PlayerSalary initialSalary = null;
				
				if(initial == 0 && lowest ==0){
					initial = now;
					initialSalary = nowSalary;
					lowest = now;
					lowestSalary = nowSalary;
				}else if(initial > now && initial < lowest){
					lowest = initial;
					lowestSalary = initialSalary;
				}else if(initial > now && now < lowest){
					lowest = now;
					lowestSalary = nowSalary;
				}else{
					initial = now;
					initialSalary = nowSalary;
				}
			}
		}
		return lowestSalary;
	}
	
	public PlayerSalary highestSalaryInLeagueInYear(String team, int year){

		int now;
		int largest = 0;
		PlayerSalary nowSalary;
		PlayerSalary highestSalary = null;
		
		for(int i = 0; i < this.Information.length; i++){
			if(this.Information[i].getYearID()==year && this.Information[i].getTeamID().equals(team)){
				String league = this.Information[i].getLeagueID();
				if(this.Information[i].getLeagueID().equals(league)){
					now = this.Information[i].getSalary();
					nowSalary = this.Information[i];
					
					int initial =0;
					PlayerSalary initialSalary = null;
				
					 if(initial > now && initial > largest){
							largest = initial;
							highestSalary = initialSalary;
					 }else if (initial < now && now > largest){
						largest = now;
						highestSalary = nowSalary;
					}else{ 
						initialSalary = nowSalary;
						initial = now;
					}
				}
			}
		}
		return highestSalary;
	}
	
	public PlayerSalary lowestSalaryInLeagueInYear(String team, int year){
		int lowest = 0;
		int now;
		PlayerSalary nowSalary;
		PlayerSalary lowestSalary = null;
		
		for(int i = 0; i < this.Information.length; i++){
			if(this.Information[i].getYearID()==year && this.Information[i].getTeamID().equals(team) ){
				String league = this.Information[i].getLeagueID();
				
				if(this.Information[i].getLeagueID().equals(league)){
					now = this.Information[i].getSalary();
					nowSalary = this.Information[i];
					
					int initial = 0;
					PlayerSalary initialSalary = null;
				
					if(initial == 0 && lowest ==0){
						initial = now;
						initialSalary = nowSalary;
						lowest = now;
						lowestSalary = nowSalary;
					}else if(initial > now && initial < lowest){
						lowest = initial;
						lowestSalary = initialSalary;
					}else if (initial > now && now < lowest){
						lowest = now;
						lowestSalary = nowSalary;
					}else{
						initial = now;
						initialSalary = nowSalary;
					}
				}
			}
		}
		return lowestSalary;
	}
	public PlayerSalary[] comparePlayersInYear(String player1, String player2, int year){
		
		PlayerSalary salary0 = findPlayerInYear(player1, year);
		PlayerSalary salary1 = findPlayerInYear(player2, year);
		PlayerSalary[] playerSal = new PlayerSalary[2];
		playerSal[0]= salary0;
		playerSal[1]= salary1;
		
		return playerSal;
	}
	
	public PlayerSalary[] getInformation() {
		return Information;
	}

	public void setInformation(PlayerSalary[] Information) {
		Information = Information;
	}
}