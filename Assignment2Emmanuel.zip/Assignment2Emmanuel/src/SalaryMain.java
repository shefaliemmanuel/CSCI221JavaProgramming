import java.util.Scanner;

public class SalaryMain {

	public static void main(String[] args) throws Exception{

		Scanner shefScanner = new Scanner(System.in);
		PlayerSalaries myInfo = new PlayerSalaries();
		
		try{
			myInfo = new PlayerSalaries("Salaries.csv");
		}catch(Exception e){
			System.out.println(e.getMessage());
			System.exit(0);
		}
		
		while(true){
			System.out.println();
			System.out.println("Welcome to ballers salary data record!");	
			System.out.println();
			System.out.println("Enter a number below:");
			System.out.println();
			System.out.println("0. Quit Program");
			System.out.println("1. Average Yearly Salary");
			System.out.println("2. Players Salary per Year");
			System.out.println("3. Highest Salary per Year");
			System.out.println("4. Lowest Salary per Year");
			System.out.println("5. Highest Salary per Team per Year");
			System.out.println("6. Lowest Salary per Team per Year");
			System.out.println("7. Highest Salary per League per Year");
			System.out.println("8. Lowest Salary per League per Year");
			System.out.println("9. Compare 2 Player's Salaries per Year");
			System.out.println();
			
			int inputNum;
			int userInput = shefScanner.nextInt();
			String userInputString;
			String userInputString2;
			
			if(userInput == 0){
				break;
			}
			
			if(userInput == 1){
				System.out.println("Enter a Year");
				inputNum = shefScanner.nextInt();
				System.out.println(myInfo.averageSalaryInYear(inputNum));
				
			}else if(userInput == 2){
				System.out.println("Enter a PlayerID + Enter a YearID (once you've hit enter)");
				userInputString = shefScanner.next();
				inputNum = shefScanner.nextInt();
				System.out.println(myInfo.findPlayerInYear(userInputString, inputNum));
				
			}else if (userInput == 3){
				System.out.println("Enter a YearID");
				inputNum = shefScanner.nextInt();
				System.out.println(myInfo.highestSalaryInYear(inputNum));
				
			}else if (userInput == 4){
				System.out.println("Enter a YearID");
				inputNum = shefScanner.nextInt();
				System.out.println(myInfo.lowestSalaryInYear(inputNum));
				
			}else if (userInput == 5){
				System.out.println("Enter a TeamID + Enter a YearID (once you've hit enter) ");
				userInputString = shefScanner.next();
				inputNum = shefScanner.nextInt();
				System.out.println(myInfo.highestSalaryInTeamInYear(userInputString, inputNum));
				
			}else if (userInput == 6){
				System.out.println("Enter a TeamID + Enter a YearID (once you've hit enter) ");
				userInputString = shefScanner.next();
				inputNum = shefScanner.nextInt();
				System.out.println(myInfo.lowestSalaryInTeamInYear(userInputString, inputNum));
				
			}else if (userInput == 7){
				System.out.println("Enter a TeamID + Enter a YearID (once you've hit enter)");
				userInputString = shefScanner.next();
				inputNum = shefScanner.nextInt();
				System.out.println(myInfo.highestSalaryInLeagueInYear(userInputString, inputNum));
				
			}else if (userInput == 8){
				System.out.println("Enter a TeamID + Enter a YearID (once you've hit enter)");
				userInputString = shefScanner.next();
				inputNum = shefScanner.nextInt();
				System.out.println(myInfo.lowestSalaryInLeagueInYear(userInputString, inputNum));
				
			}else if(userInput == 9){
				System.out.println("Enter Player 1 + Enter Enter Player 2 (once you've hit enter) + Enter YearID (once you've hit enter) ");
				userInputString = shefScanner.next();
				userInputString2 = shefScanner.next();
				inputNum = shefScanner.nextInt();
				PlayerSalary playerSalary[] = myInfo.comparePlayersInYear(userInputString, userInputString2, inputNum);
				System.out.println(playerSalary[0]);
				System.out.println(playerSalary[1]);
			}
		}
	}
}