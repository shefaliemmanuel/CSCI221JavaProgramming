
public class PlayerSalary {
	
	//Attributes:
		private int YearID;
		private String TeamID;
		private String LeagueID;
		private String PlayerID;
		private int Salary;
		
		//base constructor
		PlayerSalary(){
			this.YearID = -1;
			this.Salary = -1;
			this.TeamID = "Not Available";
			this.LeagueID = "Not Available";
			this.PlayerID = "Not Available";	
		}
		
		//constructor
		PlayerSalary(int YearID, String TeamID, String LeagueID, String PlayerID, int Salary){
			this.YearID = YearID;//2nd one is referring to one right above it
			this.TeamID = TeamID;
			this.LeagueID = LeagueID;
			this.PlayerID = PlayerID;
			this.Salary = Salary;
		}

		public String toString() {
			return "PlayerSalary [YearID=" + YearID + ", TeamID=" + TeamID + ", LeagueID=" + LeagueID + ", PlayerID="
					+ PlayerID + ", Salary=" + Salary + "]";
		}


		public int getYearID() {
			return YearID;
		}

		public void setYearID(int yearID) {
			this.YearID = yearID;
		}

		public String getTeamID() {
			return TeamID;
		}

		public void setTeamID(String teamID) {
			this.TeamID = teamID;
		}

		public String getLeagueID() {
			return LeagueID;
		}

		public void setLeagueID(String leagueID) {
			this.LeagueID = leagueID;
		}

		public String getPlayerID() {
			return PlayerID;
		}

		public void setPlayerID(String playerID) {
			this.PlayerID = playerID;
		}

		public int getSalary() {
			return Salary;
		}

		public void setSalary(int salary) {
			this.Salary = salary;
		}

}
