
public class class3 {

	public static void main(String[] args) {
		int a[]= new int [5]; //1D Array
		
		int s=5;
		fun1(s);
		
		int b[]= {-17,6,7,4,2}; //when you have a small array
		fun(b);
		
		System.out.println(a[0]);
		
		int rows =5;
		int cols = 7;
		
		for (int i=0; i< rows; i++){
			for (int j=0; j< cols; j++ ){
				System.out.println("a["+i+"]["+j+"]");
			}
		}
	}
	
	public static void fun(int[] x){
		x[0] = 5;
		
		//what does this print?
		//(a) nothing
		//(B) -17
		//(c) 5
		// answer = 5
	}

	public static void fun1(int y){
		y = 5222;
	}
}
