import java.lang.reflect.Array;

public class Arrays2D {

	public static void main(String[] args) {
		
		//print/visit bottom half of array
		int shefsArray[][]={{1,2,3,4,5},{6,7,8,9,10},{11,12,13,14,15}, {16,17,18,19,20},{21,22,23,24,25}};
		int rows= shefsArray.length();
		int colm= shefsArray[0].length();
		for (int i=rows/2+1;i<rows;i++){
			for (int j=0; colm<rows; j++){
				System.out.println(shefsArray[i][j]);
			}
		}
		
		//visit/ print all items on the middle rows
		int n= shefsArray.length();
		for(int j=0; j< n/2+1;j++){
			System.out.println(shefsArray[n/2][j]);
		}
		
		//visit/ print all items on the second to last column
		int n= shefsArray.length();
		for(int i=0; i<n;i++){
			System.out.println(shefsArray[i][n-2]);
		}
		
		//visit/ print all items on the left diagonal
		int n= shefsArray.length();
		for(int u=0; u<n;u++){
			System.out.println(shefsArray[u][u]);
		}
		
		//visit/ print all items on the right diagonal
		int n= shefsArray.length();
		for(int i=0; i<n;i++){
				System.out.println(shefsArray[i][n-i-1]);
		}
		
		//print/visit the left triangle
		int n= shefsArray.length();
		for(int i=0; i<n;i++){
			for(int j=0, j=<i;j++){
				System.out.println(shefsArray[i][j]);
			}
		}

	}

}
