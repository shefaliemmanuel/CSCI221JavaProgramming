import java.util.HashSet;
import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
/**
 * @author Sebastian
 * (Better Solution) Validate identifiers problem...
 */

public class sebSolu {

	public static void main(String[] args) {

		Scanner myScan = new Scanner(System.in);
		// Use a HashSet to store the reserved words
		HashSet<String> ReservedWords = new HashSet<String>();
		// Use a regular Expression to match the character constraints
		Pattern p = Pattern.compile("^(\\$|_|[a-zA-Z])(\\$|_|[a-zA-Z0-9])*$");
		
		while(true){
			String input = myScan.nextLine();
			if(input.equals("LAST"))
				break;
			ReservedWords.add(input);
		}
		
		while(true){
			String input = myScan.nextLine();
			if(input.equals("END"))
				break;

			Matcher m = p.matcher(input);			 
			if(m.matches() && !ReservedWords.contains(input)){
					System.out.println(input + " is valid");
			}else{
				System.out.println(input + " is invalid");
			}
		}
	}
}
