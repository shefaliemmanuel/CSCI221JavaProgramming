import java.util.Scanner;

public class ValidOrInvalid {

	public static void main(String[] args) {
		System.out.println("Please type out a list of reserved words followed by 'LAST' and a list of inputs followed by 'END': ");
		
		while(true){
			Scanner shefScanner = new Scanner(System.in);
			while (shefScanner.hasNext()){
				String reservedWords = shefScanner.nextLine(); //make scanner stop at word LAST
				
				String[] letters={"a", "b", "c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"};
		
				if(reservedWords.equals(reservedWords.charAt(0) == '_' || reservedWords.charAt(0) == '$')){
					System.out.println("The identifier begins with an alphabetic letter, _, or $!");
				}else if (reservedWords.equals("LAST")){
					System.out.println("You have entered the word Last therefore breaking out of the reserved keyword list");
					break;
				}
				String input= shefScanner.nextLine(); 
				
				if(input.equals(reservedWords)){
					System.out.print(input);
					System.out.print("is valid.");
				}else if (!(input.equals(reservedWords))){
					System.out.print(input);
					System.out.print("is not valid.");
				}else if (input.equals("END")){
					System.out.println("You have entered the word END therefore breaking out of the input list");
					break;
				}
			}}
	}}
