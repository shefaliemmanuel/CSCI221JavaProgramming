
	import java.util.Scanner;
	/**
	 * 
	 * @author Sebastian
	 * Validate identifiers problem...
	 */

	public class sebSoluSimple {

		public static void main(String[] args) {

			Scanner myScan = new Scanner(System.in);
			
			///////////////////////////////////////////////
			// Read in all reserved words and save in a String
			//
			// NOTE: The better (more advanced topic) would be to 
			// save these reserved words in a look up "hash table".
			// Hash tables are a topic in CSCI 230. 
			
			String ReservedWords = "";
			while(true){
				String input = myScan.nextLine();
				if(input.equals("LAST"))
					break;
				ReservedWords += input + " ";
			}
			
			////////////////////////////////////////////////////////////////
			//
			// Read in the input.
			
			while(true){
				String input = myScan.nextLine();
				if(input.equals("END"))
					break;
				
				/////////////////////////////////////////////////////////////////
				// Check if chracter requirements are obeyed.
				// The better way to do this would be to use a Regular Expression
				
				if(input.charAt(0) == '$' || input.charAt(0) == '_' ||
						(input.charAt(0) >= 'A' && input.charAt(0) <= 'Z') ||
						(input.charAt(0) >= 'a' && input.charAt(0) <= 'z')){
					
					int i;
					for(i = 1; i < input.length();++i){
						if(!(input.charAt(i) == '$' || input.charAt(i) == '_' ||
						(input.charAt(i) >= 'A' && input.charAt(i) <= 'Z') ||
						(input.charAt(i) >= 'a' && input.charAt(i) <= 'z') ||
						(input.charAt(i) >= '0' && input.charAt(i) <= '9'))){
							System.out.println(input + " is invalid");
							break; // breaks out of the for loop
						}	
					}
					
					/////////////////////////////////////////////////////////////////
					// Make sure it is not a reserved word.

					String temp[] = ReservedWords.split(" ");
					
					boolean isAreservedWord = false;
					for(int j = 0; j < temp.length;++j){
						if(temp[j].equals(input)){
							isAreservedWord = true;
							System.out.println(input + " is invalid");
							break;
						}
					}
					/////////////////////////////////////////////////////////////////
					// Print valid if both constraints are met. 
					if(i == input.length() && !isAreservedWord){
						System.out.println(input + " is valid");
					}
				}else{
					System.out.println(input + " is invalid");
				}
			}
		}
	}


